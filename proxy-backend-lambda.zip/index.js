const express = require('express');
const fetch = require('node-fetch');
const app = express();
app.use(express.json());

const allowedOrigins = [
  'http://localhost:3000',
  'https://your-production-frontend.com'
];

// CORS middleware
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (allowedOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
  }
  res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', '*');
  next();
});

app.options('/chat-stream', (req, res) => {
  res.sendStatus(200);
});

app.post('/chat-stream', async (req, res) => {
  try {
    console.log('Proxy: About to call Python Lambda Function URL');
    const lambdaRes = await fetch('https://ffqsqb4xk5tcvvng36dsraum4i0yzqlw.lambda-url.us-east-1.on.aws/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': req.headers.authorization
      },
      body: JSON.stringify(req.body)
    });
    console.log('Proxy: Got response from Python Lambda Function URL', lambdaRes.status);
    res.status(lambdaRes.status);
    lambdaRes.body.pipe(res); // Stream the response
  } catch (err) {
    console.error('Proxy: Error calling Python Lambda Function URL', err);
    res.status(500).json({ error: 'Proxy error', message: err.message });
  }
});

app.all('*', (req, res) => {
  res.status(404).send('Not found');
});

module.exports = app; 